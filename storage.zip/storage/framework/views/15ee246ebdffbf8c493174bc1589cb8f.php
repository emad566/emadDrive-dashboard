<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'id'=>'',
    'imageId'=>'',
    'name'=>'',
    'label'=>'',
    'required'=>'',
    'wrapperClasses'=>'col-xs-12 col-md-4',
    'labelClasses'=>'',
    'src'=>'',
    'style'=>'',
    'avatar'=>'avatar-item',
    'banner' => false,
    'label ' => '',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'id'=>'',
    'imageId'=>'',
    'name'=>'',
    'label'=>'',
    'required'=>'',
    'wrapperClasses'=>'col-xs-12 col-md-4',
    'labelClasses'=>'',
    'src'=>'',
    'style'=>'',
    'avatar'=>'avatar-item',
    'banner' => false,
    'label ' => '',
]); ?>
<?php foreach (array_filter(([
    'id'=>'',
    'imageId'=>'',
    'name'=>'',
    'label'=>'',
    'required'=>'',
    'wrapperClasses'=>'col-xs-12 col-md-4',
    'labelClasses'=>'',
    'src'=>'',
    'style'=>'',
    'avatar'=>'avatar-item',
    'banner' => false,
    'label ' => '',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>



<div id="<?php echo e($id); ?>"  class="form-group <?php echo e($id); ?> <?php echo e($wrapperClasses); ?>" >
    <label class="<?php echo e($labelClasses); ?>" for="<?php echo e($name); ?>"> <?php echo e($required); ?> <?php echo e($label); ?>

        <div class="<?php echo e($avatar); ?>">

                <img id="<?php echo e($imageId); ?>" width="150" height="150" style="<?php echo e($style); ?>" alt="<?php echo e($name); ?>"
                     src="<?php echo e($src); ?>" class="img-fluid"
                     data-toggle="tooltip" title="<?php echo e($name); ?>"
                     data-original-title="<?php echo e($name); ?>">

            <div class="avatar-badge" title="<?php echo e($name); ?>" data-toggle="tooltip"
                 data-original-title="<?php echo e($name); ?>"><i class="fas fa-edit"></i></div>
        </div>
        <input  id="<?php echo e($name); ?>" type="file"  <?php echo e($attributes); ?> name="<?php echo e($name); ?>" style="display: none"/>
    </label>
    <!-- __BLOCK__ --><?php if($errors->first($name)): ?> <span class="form-text text-danger"><?php echo e($errors->first($name)); ?></span> <?php endif; ?> <!-- __ENDBLOCK__ -->
</div>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/components/form/image.blade.php ENDPATH**/ ?>