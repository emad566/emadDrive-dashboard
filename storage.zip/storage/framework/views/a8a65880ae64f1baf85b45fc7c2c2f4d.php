<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'route'=>'',
    'iconName'=>'',
    'iconSize'=>'lg',
    'title'=>'',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'route'=>'',
    'iconName'=>'',
    'iconSize'=>'lg',
    'title'=>'',
]); ?>
<?php foreach (array_filter(([
    'route'=>'',
    'iconName'=>'',
    'iconSize'=>'lg',
    'title'=>'',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>


<li class="menu-item menu-item-submenu <?php echo e(request()->is('dashboard/'.$route) ? 'menu-item-open' : ''); ?>" aria-haspopup="true" data-menu-toggle="hover">
    <a href="javascript:;" class="menu-link menu-toggle">
                    <span class="svg-icon menu-icon">
                        <i class="<?php echo e($iconName); ?> text-primary icon-<?php echo e($iconSize); ?>"></i>
                    </span>
        <span class="menu-text"><?php echo e(__($title)); ?></span>
        <i class="menu-arrow"></i>
    </a>
    <div class="menu-submenu">
        <i class="menu-arrow"></i>
        <ul class="menu-subnav"><?php echo e($slot); ?></ul>
    </div>
</li>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/components/aside/menu.blade.php ENDPATH**/ ?>