<span class="label pulse pulse-info mr-10">
    <span class="position-relative"><?php echo e($slot); ?></span>
    <span class="pulse-ring"></span>
</span>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/components/snippets/avatar.blade.php ENDPATH**/ ?>