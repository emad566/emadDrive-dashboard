<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">


<head>
    <base href="../../../../">
    <meta charset="utf-8" />
    <title>AtmoDrive | <?php echo e(__("Login")); ?></title>
    <meta name="description" content="Login page example" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="canonical" href="https://keenthemes.com/metronic" />
    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
    <!--end::Fonts-->
    <!--begin::Page Custom Styles(used by this page)-->
    <link href="<?php echo e(asset('dashboard-assets/css/pages/login/classic/login-3.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Page Custom Styles-->
    <!--begin::Global Theme Styles(used by all pages)-->
    <link href="<?php echo e(asset('dashboard-assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/plugins/custom/prismjs/prismjs.bundle.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Theme Styles-->
    <!--begin::Layout Themes(used by all pages)-->
    <link href="<?php echo e(asset('dashboard-assets/css/themes/layout/header/base/light.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/css/themes/layout/header/menu/light.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/css/themes/layout/brand/dark.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('dashboard-assets/css/themes/layout/aside/dark.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Layout Themes-->
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard-assets/media/logos/favicon.ico')); ?>" />
</head>
<!--end::Head-->
<!--begin::Body-->

<body id="kt_body"
    class="header-fixed header-mobile-fixed subheader-enabled subheader-fixed aside-enabled aside-fixed aside-minimize-hoverable page-loading">
    <!--begin::Main-->
    <div class="d-flex flex-column flex-root">
        <!--begin::Login-->
        <div class="login login-3 login-signin-on d-flex flex-row-fluid" id="kt_login">
            <div class="d-flex flex-center bgi-size-cover bgi-no-repeat flex-row-fluid"
                style="background-image: url(<?php echo e(asset('dashboard-assets/media/bg/bg-1.jpg')); ?>);">
                <div class="login-form text-center text-white p-7 position-relative overflow-hidden">
                    <!--begin::Login Header-->
                    <div class="d-flex flex-center mb-15">
                        <a href="<?php echo e(route('login')); ?>">
                            <img src="<?php echo e(asset('assets/images/atmo.png')); ?>" class="max-h-100px" alt="AtmoDrive" />
                        </a>
                    </div>
                    <!--end::Login Header-->
                    <!--begin::Login Sign in form-->
                    <div class="login-signin">
                        <div class="mb-20">
                            <h3>Change The World</h3>
                        </div>
                        <?php if(Route::has('login')): ?>
                        <div class="hidden fixed top-0 right-0 px-6 py-4 sm:block">
                            <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('dashboard')); ?>" class="text-sm text-gray-700 underline btn btn-success">Dashboard</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="text-sm text-gray-700 underline btn btn-primary">Login</a>

                            <!-- <?php if(Route::has('register')): ?>
                            <a href="<?php echo e(route('register')); ?>" class="ml-4 text-sm text-gray-700 underline">Register</a>
                            <?php endif; ?> -->
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                    </div>
                    <!--end::Login Sign in form-->


                </div>
            </div>
        </div>
        <!--end::Login-->
    </div>

    <!--end::Page Scripts-->
</body>
<!--end::Body-->

</html>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/welcome.blade.php ENDPATH**/ ?>