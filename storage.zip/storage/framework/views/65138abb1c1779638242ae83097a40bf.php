<td <?php echo e($attributes->merge(['class' => 'px-6 py-4 whitespace-no-wrap text-sm leading-5 text-cool-gray-900 text-center'])); ?>>
    <?php echo e($slot); ?>

</td>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/components/table/cell.blade.php ENDPATH**/ ?>