<tr <?php echo e($attributes->merge(['class' => 'bg-white'])); ?>>
    <?php echo e($slot); ?>

</tr>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/components/table/row.blade.php ENDPATH**/ ?>