 <?php $__env->slot('title', null, []); ?> <?php echo e(__('Settings')); ?> <?php $__env->endSlot(); ?>
 <?php $__env->slot('header', null, []); ?> <?php echo e(__('Settings')); ?> <?php $__env->endSlot(); ?>


<div class="card card-custom" x-data="{
    show: false,
    isCreate: false,
}">
    <div class="card-header flex-wrap border-0 pt-6 pb-0">
        <div class="card-title">
            <h3 class="card-label"><?php echo e(__("Settings")); ?>

                <span class="d-block text-muted pt-2 font-size-sm"><?php echo e(__("General Settings")); ?></span>
            </h3>
        </div>

    </div>

    <div class="card-body">

    </div>
</div>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/livewire/settings/settings.blade.php ENDPATH**/ ?>