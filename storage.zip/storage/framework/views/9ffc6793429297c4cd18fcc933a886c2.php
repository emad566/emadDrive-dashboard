<div>
     <?php $__env->slot('title', null, []); ?> <?php echo e(__('Home')); ?> <?php $__env->endSlot(); ?>
     <?php $__env->slot('header', null, []); ?> <?php echo e(__('Home')); ?> <?php $__env->endSlot(); ?>
</div>
<?php /**PATH D:\wamp64\www\Atmo-dash\resources\views/livewire/dashboard/home.blade.php ENDPATH**/ ?>